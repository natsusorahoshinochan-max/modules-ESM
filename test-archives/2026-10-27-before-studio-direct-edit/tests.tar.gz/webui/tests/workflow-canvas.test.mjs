import assert from 'node:assert/strict'
import { after, afterEach, beforeEach, test } from 'node:test'
import { mkdtemp, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { build } from 'esbuild'
import { JSDOM } from 'jsdom'
import { act, createElement } from 'react'

const dom = new JSDOM('<!doctype html><html><body></body></html>', {url:'http://localhost/'})
Object.assign(globalThis,{window:dom.window,document:dom.window.document,HTMLElement:dom.window.HTMLElement,IS_REACT_ACT_ENVIRONMENT:true})
const {createRoot}=await import('react-dom/client')
const directory=await mkdtemp(join(process.cwd(),'.canvas-tests-'))
await build({entryPoints:['src/WorkflowCanvas.tsx'],bundle:true,packages:'external',platform:'node',format:'esm',jsx:'automatic',outfile:join(directory,'canvas.mjs')})
const {WorkflowCanvas,connectionProblem}=await import(pathToFileURL(join(directory,'canvas.mjs')).href)
const declaration=(id,format='data',cardinality='one')=>({id,module_id:'example',name:id,parameters:{},inputs:{input:{accepts:[format],cardinality,required:false}},outputs:{output:{format,cardinality}}})
const node=(id,type='operation')=>({id,type,inputs:{},parameters:{}})
const edge=(source,target)=>({source,source_port:'output',target,target_port:'input'})
const catalog={nodes:[declaration('operation'),declaration('other','other'),declaration('batch','data','many')],modules:[]}
let root,container,props,connections,disconnects,moves,added,hit
async function render(change={}){props={...props,...change};await act(async()=>root.render(createElement(WorkflowCanvas,props)));const stage=container.querySelector('.canvas-viewport');stage.getBoundingClientRect=()=>({left:0,top:0,width:900,height:600});return stage}
async function pointer(target,type,x,y){await act(async()=>{const event=new window.MouseEvent(type,{bubbles:true,clientX:x,clientY:y,button:0});Object.defineProperty(event,'pointerId',{value:7});target.dispatchEvent(event)})}
async function key(target,value,options={}){await act(async()=>target.dispatchEvent(new window.KeyboardEvent('keydown',{bubbles:true,key:value,...options})))}
const socket=(id,side)=>container.querySelector(`[data-socket-node="${id}"][data-socket-side="${side}"]`)
async function drag(from,to){const stage=container.querySelector('.canvas-viewport');await pointer(from,'pointerdown',50,50);hit=to;await pointer(stage,'pointermove',230,180);await pointer(stage,'pointerup',230,180)}
beforeEach(async()=>{
  connections=[];disconnects=[];moves=[];added=[];hit=null
  document.elementFromPoint=()=>hit
  container=document.createElement('div');document.body.append(container);root=createRoot(container)
  props={flow:{nodes:[node('a'),node('b'),node('c')],edges:[edge('a','b')]},catalog,layout:{a:{x:10,y:20},b:{x:400,y:20},c:{x:800,y:20}},disabled:false,selectedSource:{source:'',source_port:''},onSource(){},onTarget(){},onMove:(id,position)=>moves.push({[id]:position}),onMoveMany:positions=>moves.push(positions),onConnect:(edge,index)=>connections.push({edge,index}),onDisconnect:index=>disconnects.push(index),onAdd:(type,position)=>added.push({type,position}),renderNode:()=>createElement('div',null,'Node parameters')}
  await render()
})
afterEach(async()=>{await act(async()=>root.unmount());container.remove()})
after(async()=>{await rm(directory,{recursive:true,force:true});dom.window.close()})

test('public declarations reject incompatible, occupied, cyclic and many-to-one connections',()=>{
  const flow={nodes:[node('a'),node('b'),node('c'),node('x','other'),node('batch','batch')],edges:[edge('a','b'),edge('b','c')]}
  assert.match(connectionProblem(flow,catalog,edge('a','x')),/格式/)
  assert.match(connectionProblem(flow,catalog,edge('c','b')),/已有/)
  assert.match(connectionProblem(flow,catalog,edge('c','a')),/循环/)
  assert.match(connectionProblem(flow,catalog,edge('batch','a')),/一个/)
  assert.equal(connectionProblem(flow,catalog,edge('a','c'),1),'')
  assert.equal(connectionProblem({...flow,nodes:flow.nodes.map(n=>n.id==='a'?{...n,inputs:{input:['bound']}}:n)},catalog,edge('b','a')).includes('已有'),true)
})
test('only socket circles start wiring; labels select without disconnecting',async()=>{
  const label=socket('b','input').parentElement.querySelector('span')
  await drag(label,container.querySelector('.canvas-viewport'))
  assert.equal(container.querySelector('.wire-preview'),null)
  assert.deepEqual(disconnects,[])
  assert.deepEqual(connections,[])
})
test('input drag reconnects atomically and output drag preserves an existing branch',async()=>{
  await drag(socket('b','input'),socket('c','input'))
  assert.deepEqual(connections,[{edge:edge('a','c'),index:0}])
  assert.deepEqual(disconnects,[])
  connections=[]
  await drag(socket('a','output'),socket('c','input'))
  assert.deepEqual(connections,[{edge:edge('a','c'),index:undefined}])
})
test('dragging a connected input to blank disconnects; invalid or cancelled gestures retain it',async()=>{
  const stage=container.querySelector('.canvas-viewport')
  await drag(socket('b','input'),stage)
  assert.deepEqual(disconnects,[0])
  disconnects=[]
  await render({flow:{nodes:[node('a'),node('b'),node('c','other')],edges:[edge('a','b')]}})
  await drag(socket('b','input'),socket('c','input'))
  assert.deepEqual(disconnects,[]);assert.deepEqual(connections,[])
  assert.match(container.querySelector('.canvas-status').textContent,/原连接保持/)
  await pointer(socket('b','input'),'pointerdown',50,50)
  hit=stage;await pointer(stage,'pointermove',120,100);await key(stage,'Escape');await pointer(stage,'pointerup',120,100)
  assert.deepEqual(disconnects,[])
})
test('expanding properties leaves positions and viewport untouched across data updates',async()=>{
  const stage=container.querySelector('.canvas-viewport')
  await key(stage,' ');await pointer(stage,'pointerdown',0,0);await pointer(stage,'pointermove',70,90);await pointer(stage,'pointerup',70,90)
  const transform=container.querySelector('.canvas-surface').style.transform
  const before=[...container.querySelectorAll('[data-canvas-node]')].map(el=>[el.style.left,el.style.top])
  const toggle=container.querySelector('[aria-label="Properties node 1"]')
  await act(async()=>toggle.click())
  assert.equal(toggle.getAttribute('aria-expanded'),'true')
  assert.deepEqual([...container.querySelectorAll('[data-canvas-node]')].map(el=>[el.style.left,el.style.top]),before)
  await render({flow:{...props.flow,nodes:props.flow.nodes.map(n=>({...n,parameters:{changed:true}}))}})
  assert.equal(container.querySelector('.canvas-surface').style.transform,transform)
  await act(async()=>toggle.click())
  assert.equal(toggle.getAttribute('aria-expanded'),'false')
})
test('canvas coordinates account for zoom during a complete drag',async()=>{
  await act(async()=>container.querySelector('[aria-label="放大"]').click())
  const stage=container.querySelector('.canvas-viewport'),handle=container.querySelector('[aria-label="Move node 1"]')
  await pointer(handle,'pointerdown',50,50);await pointer(stage,'pointermove',170,110);await pointer(stage,'pointerup',170,110)
  assert.deepEqual(moves,[{a:{x:110,y:70}}])
})
test('catalog entries support drag placement and click then place',async()=>{
  const stage=container.querySelector('.canvas-viewport')
  await act(async()=>[...container.querySelectorAll('button')].find(button=>button.textContent.includes('添加节点')).click())
  const entry=container.querySelector('.canvas-library-items button')
  await pointer(entry,'pointerdown',30,30);hit=stage;await pointer(stage,'pointermove',400,200);await pointer(stage,'pointerup',400,200)
  assert.deepEqual(added,[{type:'operation',position:{x:250,y:180}}])
  await act(async()=>[...container.querySelectorAll('button')].find(button=>button.textContent.includes('添加节点')).click())
  await act(async()=>container.querySelector('.canvas-library-items button').click())
  await pointer(stage,'pointerdown',500,300)
  assert.deepEqual(added[1],{type:'operation',position:{x:350,y:280}})
})

test('external deletion and undo prune selection before dragging surviving selected nodes',async()=>{
  const stage=container.querySelector('.canvas-viewport')
  await key(stage,'a',{metaKey:true})
  await act(async()=>container.querySelector('[aria-label="Properties node 3"]').click())
  assert.match(container.querySelector('.canvas-selected-actions').textContent,/3 个已选/)
  await render({flow:{...props.flow,nodes:props.flow.nodes.filter(n=>n.id!=='c')}})
  assert.match(container.querySelector('.canvas-selected-actions').textContent,/2 个已选/)
  const handle=container.querySelector('[aria-label="Move node 1"]')
  await pointer(handle,'pointerdown',50,50);await pointer(stage,'pointermove',70,80);await pointer(stage,'pointerup',70,80)
  assert.deepEqual(moves,[{a:{x:30,y:50},b:{x:420,y:50}}])
  await render({flow:{...props.flow,nodes:[...props.flow.nodes,node('c')]}})
  assert.equal(container.querySelector('[data-canvas-node="c"]').classList.contains('selected'),false)
  assert.equal(container.querySelector('[aria-label="Properties node 3"]').getAttribute('aria-expanded'),'false')
})

test('synchronous host rejection reports the reason and retains the original connection',async()=>{
  await render({onConnect:()=>{throw new Error('Input is already bound to a subflow boundary')}})
  await drag(socket('b','input'),socket('c','input'))
  assert.match(container.querySelector('.canvas-status').textContent,/subflow boundary/)
  assert.deepEqual(disconnects,[])
  assert.equal(container.querySelectorAll('.wire:not(.wire-preview)').length,1)
  assert.equal(container.querySelector('.wire-preview'),null)
})
