import assert from 'node:assert/strict'
import {after,test} from 'node:test'
import {JSDOM} from 'jsdom'
import * as React from 'react'
import {execFileSync} from 'node:child_process'
const source=execFileSync(process.env.WORKBENCH_PYTHON||'python3',['-c',`
import tempfile
from pathlib import Path
from fastapi.testclient import TestClient
from protein_workbench_public.bootstrap import create_application
with tempfile.TemporaryDirectory() as directory:
    with TestClient(create_application(data_root=Path(directory))) as client:
        module = next(item for item in client.get('/api/modules').json() if item['id']=='workbench.sequence_edit')
        response = client.get(module['ui_url'])
        response.raise_for_status()
        print(response.text,end='')
`],{cwd:new URL('../../',import.meta.url),encoding:'utf8'})
const {register,selectTrackRange,coordinateOperation,transformDocument,cameraFrame,backboneSegments}=await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`)
const dom=new JSDOM('<!doctype html><html><body></body></html>',{url:'http://localhost/'})
Object.assign(globalThis,{window:dom.window,document:dom.window.document,HTMLElement:dom.window.HTMLElement,IS_REACT_ACT_ENVIRONMENT:true})
Object.defineProperty(globalThis,'navigator',{configurable:true,value:dom.window.navigator})
const {createRoot}=await import('react-dom/client')
const extension=register({React}).editors[0],Editor=extension.component
after(()=>dom.window.close())
const position=(id,residue,coordinates=null)=>({id,residue,coordinates,secondary_structure:null,sasa:null,function_annotations:[]})
const base={id:'protein',sequence:'ACDE',positions:[position('a','A',{CA:[0,0,0]}),position('c','C',{CA:[3.8,0,0]}),position('d','D'),position('e','E',{CA:[10,0,0]})],random_operations:[]}
const clone=value=>JSON.parse(JSON.stringify(value))

function harness(overrides={}){
 const calls=[],updates=[],cancelled=[],snapshots=new Map()
 const context={projectId:'p',nodeId:'edit',revision:0,parameters:{sequence:'ACDE'},bindings:{},edges:[],inputs:{},host:{
  async preview(id,inputs,parameters){calls.push({id,inputs,parameters});let doc=clone(inputs.source?.[0]?.interaction?snapshots.get(inputs.source[0].interaction):base)
   for(const op of parameters.operations??[]){if(op.kind==='update')doc.positions=doc.positions.map(row=>op.positions.includes(row.id)?{...row,...op.changes}:row);else if(op.kind==='delete')doc.positions=doc.positions.filter(row=>!op.positions.includes(row.id))}
   doc.sequence=doc.positions.map(row=>row.residue??'_').join('');const token=`preview-${calls.length}`;snapshots.set(token,doc);return{id:token,data:{document:doc},outputs:['edited']}
  },async cancelPreview(id){cancelled.push(id)},...overrides.host},async update(change){updates.push(change)},...Object.fromEntries(Object.entries(overrides).filter(([key])=>key!=='host'))}
 const container=document.createElement('div');document.body.append(container);const root=createRoot(container)
 const render=async(extra={})=>React.act(async()=>root.render(React.createElement(Editor,{context,parameters:context.parameters,readOnly:false,...extra})))
 const click=async name=>{const button=[...container.querySelectorAll('button')].find(button=>button.textContent===name||button.getAttribute('aria-label')===name);assert.ok(button,name);await React.act(async()=>button.click())}
 const select=async(track,index)=>React.act(async()=>container.querySelector(`[aria-label="${track} ${index}"]`).click())
 const close=async()=>{await React.act(async()=>root.unmount());container.remove()}
 return{context,container,root,render,click,select,close,calls,updates,cancelled}
}

test('Studio expands as a workspace and each track retains its independent selection',async()=>{
 assert.deepEqual(extension.workspace,{title:'Protein Studio',openLabel:'打开 Protein Studio'})
 const t=harness();try{
  await t.render();await t.select('序列',1);await t.select('二级结构',3)
  assert.equal(t.container.querySelector('[aria-label="序列 1"]').getAttribute('aria-pressed'),'true')
  assert.equal(t.container.querySelector('[aria-label="二级结构 3"]').getAttribute('aria-pressed'),'true')
  assert.equal(t.container.querySelector('[aria-label="三维坐标 3"]').getAttribute('aria-pressed'),'false')
  await t.click('预览');await t.click('应用')
  assert.deepEqual(t.calls.at(-1).inputs.source,[{interaction:'preview-1',output:'edited'}])
  assert.deepEqual(t.calls.at(-1).parameters.operations,[{kind:'update',positions:['d'],changes:{secondary_structure:'H'}}])
  assert.equal(t.updates.length,0)
  await t.select('序列',1);await t.click('清空');await t.click('应用')
  assert.equal(t.calls.at(-1).parameters.operations[0].changes.residue,null)
  assert.equal(t.container.querySelector('[aria-label="二级结构 3"]').textContent,'H')
  await t.click('撤销');assert.equal(t.container.querySelector('[aria-label="序列 1"]').textContent,'A')
  await t.click('重做');assert.equal(t.container.querySelector('[aria-label="序列 1"]').textContent,'·')
  await t.click('完成并返回画布');assert.equal(t.updates.length,1)
  assert.deepEqual(t.updates[0],{document:{interaction:'preview-3',output:'edited'}})
  assert.doesNotMatch(t.container.textContent,/固定|可变|Fixed|Prompt/)
 }finally{await t.close()}
})

test('unapplied track operations coexist and Done explicitly resolves them in one accepted delivery',async()=>{
 const t=harness();try{
  await t.render();await t.select('序列',2);await t.click('清空')
  await t.select('二级结构',4);await t.click('预览')
  assert.equal(t.container.querySelector('[aria-label="序列 2"]').textContent,'·')
  assert.equal(t.container.querySelector('[aria-label="二级结构 4"]').textContent,'H')
  await t.click('完成并返回画布');assert.equal(t.updates.length,0)
  assert.ok(t.container.querySelector('[aria-label="处理未应用的编辑"]'))
  await t.click('应用全部并完成');assert.equal(t.updates.length,1)
  assert.deepEqual(t.calls.at(-1).parameters.operations.map(op=>op.positions),[['c'],['e']])
 }finally{await t.close()}
})

test('cancel leaves node unchanged and releases all temporary snapshots',async()=>{
 let closed=0;const t=harness();try{
  await t.render({onClose:()=>closed++});await t.select('三维坐标',1);await t.click('清空坐标');await t.click('应用')
  assert.equal(t.updates.length,0);await t.click('取消编辑')
  assert.equal(closed,1);assert.deepEqual(t.cancelled.sort(),['preview-1','preview-2'])
 }finally{await t.close()}
})

test('reopening loads the accepted document; explicitly choosing upstream does not replay old edits',async()=>{
 const t=harness({document:{id:'accepted'},parameters:{operations:[{kind:'delete',indices:[1]}]},inputs:{source:{packages:[],available:[{package:{id:'upstream'},label:'上游结果'}]}}})
 try{
  await t.render()
  assert.deepEqual(t.calls[0].inputs.source,['accepted'])
  assert.deepEqual(t.calls[0].parameters,{})
  await t.click('载入输入')
  await React.act(async()=>{const select=t.container.querySelector('[aria-label="载入来源"]');select.value='upstream';select.dispatchEvent(new window.Event('change',{bubbles:true}))})
  await t.click('打开编辑')
  assert.deepEqual(t.calls.at(-1).inputs.source,['upstream'])
  assert.equal(t.calls.at(-1).parameters.operations,undefined)
  assert.equal(t.updates.length,0)
  await t.click('取消编辑')
  assert.equal(t.updates.length,0)
 }finally{await t.close()}
})

test('failed final adoption retains actual draft for retry',async()=>{
 let attempts=0;const t=harness({async update(){attempts++;if(attempts===1)throw new Error('disk full')}})
 try{
  await t.render();await t.select('序列',1);await t.click('清空');await t.click('应用');await t.click('完成并返回画布')
  assert.match(t.container.textContent,/disk full/);assert.equal(t.cancelled.includes('preview-2'),false)
  await t.click('完成并返回画布');assert.equal(attempts,2)
 }finally{await t.close()}
})

test('cancelled initial loading releases a late preview without updating the node',async()=>{
 let resolve,signal;const t=harness({host:{preview(id,inputs,parameters,options){signal=options.signal;return new Promise(done=>{resolve=done})}}})
 try{
  await t.render();await t.click('取消加载');assert.equal(signal.aborted,true)
  await React.act(async()=>resolve({id:'late',data:{document:base},outputs:['edited']}))
  assert.deepEqual(t.cancelled,['late']);assert.equal(t.updates.length,0)
 }finally{await t.close()}
})

test('external node revision invalidates editor snapshots and selections',async()=>{
 const t=harness();try{
  await t.render();await t.select('序列',1);await t.click('清空')
  await React.act(async()=>t.root.render(React.createElement(Editor,{context:{...t.context,revision:1,parameters:{sequence:'WW'}},parameters:{sequence:'WW'},readOnly:false})))
  assert.match(t.container.textContent,/节点输入已改变/);assert.equal(t.container.querySelector('[aria-label="序列 1"]'),null)
  assert.deepEqual(t.cancelled,['preview-1'])
 }finally{await t.close()}
})

test('range selection and 3D transforms preserve real geometry and never bridge absent coordinates',()=>{
 assert.deepEqual(selectTrackRange(base.positions,['e'],'a','c',true),['e','a','c'])
 assert.equal(backboneSegments(base.positions).length,1)
 const operation=coordinateOperation(base.positions,['a','c'],[2,3,4],[0,0,180]),result=transformDocument(base,operation)
 for(let axis=0;axis<3;axis++)assert.ok(Math.abs(result.positions[0].coordinates.CA[axis]-[5.8,3,4][axis])<1e-8)
 assert.deepEqual(result.positions[3],base.positions[3]);assert.equal(result.positions[2].coordinates,null)
 const frame=cameraFrame([[0,0,0],[3.8,0,0]],800,400,{yaw:0,pitch:0,zoom:1,pan:[0,0]})
 assert.deepEqual(frame.project(frame.center),[400,200,0])
})

test('local adoption chooses real source residues without exposing mapping JSON',async()=>{
 const geometry=[{model:1,chain:'X',author_number:30,insertion_code:'',residue_name:'LYS',atom_name:'CA',position:[42,3,4]}]
 const t=harness(),normal=t.context.host.preview
 t.context.inputs.structures={packages:[{id:'reference',entry:'structures.json',format:'workbench.structure_set'}]}
 t.context.host.readFile=async()=>new Blob([JSON.stringify({objects:[{id:'reference-object',name:'Reference protein'}]})])
 t.context.host.readPreviewFile=async()=>new Blob([JSON.stringify(geometry)])
 t.context.host.preview=async(id,inputs,parameters,options)=>{
  if(id!=='workbench.sequence_structure')return normal(id,inputs,parameters,options)
  t.calls.push({id,inputs,parameters});const document=clone(base)
  if(parameters.operation)document.positions[0].coordinates={CA:[42,3,4]}
  return{id:`preview-${t.calls.length}`,data:{document,view_file:'view.json'},outputs:['edited']}
 }
 try{
  await t.render();await t.select('三维坐标',1);await t.click('从结构采用');await t.click('读取来源残基');await t.click('30 · LYS');await t.click('预览采用')
  assert.deepEqual(t.calls.at(-1).parameters.operation,{kind:'adopt_structure',tracks:['coordinates'],mapping:[{edit_position:'a',position:{model:1,chain:'X',author_number:30,insertion_code:'',residue_name:'LYS'}}]})
  assert.deepEqual(t.calls.at(-1).inputs.structures,['reference'])
  assert.equal(t.updates.length,0);await t.click('确认采用');assert.equal(t.updates.length,0)
  await t.click('完成并返回画布');assert.equal(t.updates.length,1)
 }finally{await t.close()}
})
