"""Prepared five-track protein fixtures: no editor selection or permission state."""
from copy import deepcopy


def prepared_protein(*, secondary_structure=None, sasa=None, function_annotations=None):
    return {
        'id': 'edited',
        'positions': [
            {'id': 'p1', 'structure_position': {'structure': 'input-structure', 'position': {'model': '1', 'chain': 'Q', 'author_number': 92, 'insertion_code': 'B', 'residue_name': 'ALA'}},
             'source': {'object': 'source', 'sequence_index': 1, 'position': {'sequence_index': 1, 'chain': 'Z', 'author_number': 42, 'insertion_code': 'A'}}},
            {'id': 'p2'},
        ],
        'tracks': {
            'sequence': ['A', None],
            'coordinates': [{'CA': [1., 2., 3.]}, None],
            'secondary_structure': deepcopy(secondary_structure or [None, None]),
            'sasa': deepcopy(sasa or [None, None]),
            'function_annotations': deepcopy(function_annotations or []),
        },
    }
