"""Protein Studio fixtures, encoded from actual track values."""
import json
from modules.sequence_edit.target_delivery import protein_manifest
from modules.structure_io.target import write_target


def row(identity, residue, coordinates=None, **values):
    return {'id':identity, 'residue':residue, 'coordinates':coordinates,
            'secondary_structure':None, 'sasa':None, 'function_annotations':[], **values}


def protein_files(document):
    return {'edited.json':json.dumps(protein_manifest(document)).encode(),
            'editor.json':json.dumps(document).encode(),
            'target.cif':write_target([{'residue':position['residue'] or '_',
                'atoms':position['coordinates'] or {}, **position.get('target_author', {})}
                for position in document['positions']])}


def assert_manifest(document, actual):
    assert actual == protein_manifest(document)
