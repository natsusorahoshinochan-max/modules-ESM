"""Public-only editor fixture for temporary editor session tests."""
from protein_workbench_public.module_api import Delivery, InputPort, Interaction, InteractionResult, Module


def edit(call, runtime):
    value = ''
    if call.inputs['source']:
        with call.inputs['source'][0].open('text') as stream:
            value = stream.read().decode()
    value += call.parameters.get('append', '')
    (runtime.workdir / 'text').write_text(value)
    return InteractionResult({'text': value}, {'edited': Delivery('test.text', 'text', {'text': 'text'})})


def module():
    return Module('test.editor_session', 'Editor session',
        interactions=(Interaction('test.edit', edit, {'source': InputPort(('test.text',), required=False)}),))
