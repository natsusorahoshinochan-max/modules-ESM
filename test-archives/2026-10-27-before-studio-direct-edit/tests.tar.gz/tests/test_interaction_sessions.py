"""Chained previews own their input files and survive receipt until editor commit."""
from fastapi.testclient import TestClient
from protein_workbench_public.bootstrap import create_application


def begin(client, project, inputs=None, append=''):
    response = client.post(f'/api/projects/{project}/interactions', json={
        'interaction': 'test.edit', 'inputs': inputs or {}, 'parameters': {'append': append}})
    response.raise_for_status()
    return response.json()['id']


def test_chained_preview_is_independent_and_accept_is_retryable(tmp_path):
    with TestClient(create_application(data_root=tmp_path)) as client:
        client.post('/api/modules', json={'entry_point': 'tests.fixtures.host_editor_session:module'}).raise_for_status()
        project = client.post('/api/projects', json={'name': 'Session'}).json()['id']
        first = begin(client, project, append='A')
        client.post(f'/api/interactions/{first}/execute').raise_for_status()
        second = begin(client, project, {'source': [{'interaction': first, 'output': 'edited'}]}, 'B')
        client.delete(f'/api/interactions/{first}').raise_for_status()
        result = client.post(f'/api/interactions/{second}/execute')
        assert result.json()['data'] == {'text': 'AB'}
        assert client.get(f'/api/projects/{project}/packages').json() == []
        accepted = client.post(f'/api/interactions/{second}/accept', json={'output': 'edited'})
        accepted.raise_for_status()
        assert client.get(f'/api/interactions/{second}/file', params={'output': 'edited', 'key': 'text'}).text == 'AB'
        client.delete(f'/api/interactions/{second}').raise_for_status()
        client.delete(f'/api/interactions/{second}').raise_for_status()
        assert list((tmp_path / 'work').iterdir()) == []
        assert len(client.get(f'/api/projects/{project}/packages').json()) == 1


def test_temporary_input_rejects_wrong_project_and_missing_output_without_leaks(tmp_path):
    with TestClient(create_application(data_root=tmp_path)) as client:
        client.post('/api/modules', json={'entry_point': 'tests.fixtures.host_editor_session:module'}).raise_for_status()
        project = client.post('/api/projects', json={'name': 'Session'}).json()['id']
        other = client.post('/api/projects', json={'name': 'Other'}).json()['id']
        token = begin(client, project, append='A')
        client.post(f'/api/interactions/{token}/execute').raise_for_status()
        for target, output in [(other, 'edited'), (project, 'missing')]:
            response = client.post(f'/api/projects/{target}/interactions', json={'interaction': 'test.edit', 'inputs': {'source': [{'interaction': token, 'output': output}]}})
            assert response.status_code == 400
            assert len(list((tmp_path / 'work').iterdir())) == 1
        client.delete(f'/api/interactions/{token}').raise_for_status()
