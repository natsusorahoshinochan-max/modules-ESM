"""Portable independent tracks, explicit combination and current coordinate use."""
import json
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from protein_workbench_public.bootstrap import create_application
from protein_workbench_public.module_api import Call
from tests.test_structure_io import run
from tests.test_studio_generation import Package
from tests.test_sequence_io import upload
from tests.run_helpers import wait_response


def test_all_tracks_deliver_and_sequence_preserves_blanks_and_special_letters(tmp_path):
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Track outputs'}).json()['id']
        result = run(client, project, 'workbench.edit_sequence', {}, {'sequence': 'A_XBZJUO'})
        assert result['status'] == 'succeeded', result
        assert set(result['outputs']) == {'edited', 'sequence', 'coordinates', 'secondary_structure', 'sasa', 'function_annotations'}
        documents = {}
        for port, ids in result['outputs'].items():
            assert len(ids) == 1
            info = next(item for item in client.get(f'/api/projects/{project}/packages').json() if item['id'] == ids[0])
            documents[port] = client.get(f'/api/packages/{ids[0]}/file', params={'key': info['entry']}).json()
        seq = documents['sequence']['objects'][0]
        assert seq['sequence'] == 'A_XBZJUO'
        for port in ('coordinates', 'secondary_structure', 'sasa', 'function_annotations'):
            obj = documents[port]['objects'][0]
            assert obj['id'] == seq['id']
            assert obj['positions'] == seq['positions']
            assert obj['values'] == ([] if port == 'function_annotations' else [None] * 8)


def test_individual_tracks_combine_only_explicit_values_and_require_correspondence():
    from modules.generation.sources import read_inputs
    positions = [{'sequence_index': 1, 'id': 'p1'}, {'sequence_index': 2, 'id': 'p2'}]
    ss = Package('workbench.secondary_structure', {'objects': [{'id': 'p', 'positions': positions, 'values': ['H', None]}]})
    source = read_inputs(Call(inputs={'secondary_structure': (ss,)}, parameters={}, settings={}))[0]
    assert source['tracks'] == {'sequence': [None, None], 'secondary_structure': ['H', None]}
    seq = Package('workbench.sequence', {'objects': [{'id': 'p', 'positions': positions, 'sequence': 'A_'}]})
    source = read_inputs(Call(inputs={'sequence': (seq,), 'secondary_structure': (ss,)}, parameters={}, settings={}))[0]
    assert source['tracks'] == {'sequence': ['A', None], 'secondary_structure': ['H', None]}
    other = Package('workbench.sasa', {'objects': [{'id': 'different', 'positions': positions, 'values': [0, None]}]})
    with pytest.raises(ValueError, match='same object'):
        read_inputs(Call(inputs={'sequence': (seq,), 'sasa': (other,)}, parameters={}, settings={}))
    with pytest.raises(ValueError, match='either'):
        read_inputs(Call(inputs={'source': (seq,), 'sequence': (seq,)}, parameters={}, settings={}))
    swapped = Package('workbench.sasa', {'objects': [{'id': 'p', 'positions': [
        {'sequence_index': 1, 'id': 'p2'}, {'sequence_index': 2, 'id': 'p1'}], 'values': [0, None]}]})
    with pytest.raises(ValueError, match='same object'):
        read_inputs(Call(inputs={'sequence': (seq,), 'sasa': (swapped,)}, parameters={}, settings={}))


def test_general_sequence_reader_preserves_gaps_and_predictor_checks_completeness(tmp_path):
    from modules.sequence_io.formats import read_sequences
    from modules.folding import execute
    sequence = Package('workbench.sequence', {'objects': [{'id': 'p', 'sequence': 'AX_U'}]})
    assert read_sequences(sequence)[0]['sequence'] == 'AX_U'
    with pytest.raises(ValueError, match='position'):
        execute(Call(inputs={'sequence': (sequence,)}, parameters={}, settings={}), SimpleNamespace(workdir=tmp_path))


def test_confirmed_document_keeps_input_edge_and_survives_copy(tmp_path):
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Confirmed editor content'}).json()['id']
        prepared = run(client, project, 'workbench.edit_sequence', {}, {'sequence': 'AX_'})['outputs']['edited'][0]
        edge = {'source': 'upstream', 'source_port': 'sequence', 'target': 'studio', 'target_port': 'source'}
        flow = {'nodes': [
            {'id': 'upstream', 'type': 'workbench.edit_sequence', 'parameters': {'sequence': 'GGG'}, 'inputs': {}},
            {'id': 'studio', 'type': 'workbench.edit_sequence', 'parameters': {}, 'inputs': {}, 'document': prepared},
        ], 'edges': [edge]}
        client.put(f'/api/projects/{project}', json={'flow': flow, 'layout': {}}).raise_for_status()
        result = wait_response(client, client.post(f'/api/projects/{project}/runs')).json()
        assert result['status'] == 'succeeded', result
        output = result['nodes']['studio']['outputs']['sequence'][0]
        assert client.get(f'/api/packages/{output}/file', params={'key': 'sequence.json'}).json()['objects'][0]['sequence'] == 'AX_'
        assert client.get(f'/api/projects/{project}').json()['flow']['edges'] == [edge]
        copied = client.post(f'/api/projects/{project}/copies', json={'name': 'Independent copy'}).json()
        copied_document = copied['flow']['nodes'][1]['document']
        assert copied_document != prepared
        client.delete(f'/api/projects/{project}').raise_for_status()
        result = wait_response(client, client.post(f'/api/projects/{copied["id"]}/runs')).json()
        assert result['status'] == 'succeeded', result
        assert copied['flow']['edges'] == [edge]


def test_coordinate_track_exports_current_atoms_without_refilling_gaps(tmp_path):
    from tests.fixtures.studio import row
    from modules.structure_io import parse, atoms
    document = {'id': 'p', 'sequence': 'ACD', 'random_operations': [], 'positions': [
        row('a', 'A', {'CA': [11, 12, 13]}), row('b', 'C'), row('c', 'D', {'CA': [21, 22, 23]})]}
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Current atoms'}).json()['id']
        prepared = run(client, project, 'workbench.edit_sequence', {}, {'document': document})
        assert prepared['status'] == 'succeeded', prepared
        coords = prepared['outputs']['coordinates'][0]
        exported = run(client, project, 'workbench.export_structure', {'structures': [coords]}, {'format': 'mmcif'})
        assert exported['status'] == 'succeeded', exported
        package = exported['outputs']['structures'][0]
        manifest = client.get(f'/api/packages/{package}/file', params={'key': 'manifest.json'}).json()
        file = manifest['objects'][0]['structure']['file']
        actual = atoms(parse(client.get(f'/api/packages/{package}/file', params={'key': file}).content, 'mmcif'))
        assert [a['position'] for a in actual] == [[11, 12, 13], [21, 22, 23]]
        assert [a['author_number'] for a in actual] == [1, 3]
        reopened = run(client, project, 'workbench.edit_sequence', {'source': [coords]}, {})
        assert reopened['status'] == 'succeeded', reopened
        value = client.get(f'/api/packages/{reopened["outputs"]["edited"][0]}/file', params={'key': 'edited.json'}).json()
        assert value['tracks']['coordinates'] == [{'CA': [11, 12, 13]}, None, {'CA': [21, 22, 23]}]
        assert value['tracks']['secondary_structure'] == [None] * 3
        assert value['tracks']['sasa'] == [None] * 3
        assert value['tracks']['function_annotations'] == []


def test_independent_track_request_reaches_tool_and_returns_to_studio(tmp_path):
    from modules.generation.sequence import execute
    from modules.generation.contract import GenerateResult
    from modules.sequence_edit import _initial
    from modules.sequence_edit.target_delivery import prepared_tracks
    positions = [{'sequence_index': i + 1, 'id': f'p{i}'} for i in range(3)]
    sequence = Package('workbench.sequence', {'objects': [{'id': 'protein', 'positions': positions, 'sequence': 'A_D'}]})
    sasa = Package('workbench.sasa', {'objects': [{'id': 'protein', 'positions': positions, 'values': [None, 0, None]}]})
    seen = []
    def tool(request, parameters, runtime):
        seen.append(request.tracks)
        assert request.tracks == {'sequence': ['A', None, 'D'], 'sasa': [None, 0, None]}
        (runtime.workdir / 'native.json').write_text(json.dumps({'tracks': {'sequence': 'ACD'}, 'metrics': {}}))
        return GenerateResult(tracks={'sequence': list('ACD'), 'sasa': [None, 0, None]}, values_file='native.json', parameters={})
    runtime = SimpleNamespace(workdir=tmp_path, cancelled=False, progress=lambda _: None)
    result = execute(Call(inputs={'sequence': (sequence,), 'sasa': (sasa,)}, parameters={}, settings={},
                          tools={'esm3': tool}, tool_choices={'esm3': 'test'}), runtime)
    assert result.status == 'succeeded', result.diagnostics
    output = result.outputs['generated'][0]
    manifest = json.loads((tmp_path / output.files[output.entry]).read_text())
    reopened = _initial(Call(inputs={'source': (Package(output.format, manifest),)}, parameters={}, settings={}))
    assert prepared_tracks(reopened) == {'sequence': list('ACD'), 'coordinates': [None] * 3,
        'secondary_structure': [None] * 3, 'sasa': [None, 0, None], 'function_annotations': []}
    assert len(seen) == 1


def test_sequence_export_preserves_single_letters_and_rejects_blanks_without_conversion(tmp_path):
    from modules.sequence_io import export_sequences
    runtime = SimpleNamespace(workdir=tmp_path, cancelled=False)
    package = Package('workbench.sequence', {'objects': [{'id': 'protein', 'sequence': 'AXBZJUO'}]})
    export_sequences(Call(inputs={'sequences': (package,)}, parameters={}, settings={}), runtime)
    assert (tmp_path / 'sequences.fasta').read_text() == '>protein\nAXBZJUO\n'
    blank = Package('workbench.sequence', {'objects': [{'id': 'protein', 'sequence': 'A_X'}]})
    with pytest.raises(ValueError, match='position 2'):
        export_sequences(Call(inputs={'sequences': (blank,)}, parameters={}, settings={}), runtime)


def test_current_coordinate_output_is_consumed_by_real_structure_comparison(tmp_path):
    from tests.fixtures.studio import row
    points = [[0, 0, 0], [3.8, 0, 0], [5.6, 3.2, 0], [8.1, 5.1, 2], [9.4, 8.2, 3.1]]
    document = {'id': 'current', 'sequence': 'ACDEF', 'random_operations': [],
        'positions': [row(f'p{i}', aa, {'CA': xyz}) for i, (aa, xyz) in enumerate(zip('ACDEF', points))]}
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Compare current coordinates'}).json()['id']
        prepared = run(client, project, 'workbench.edit_sequence', {}, {'document': document})
        coordinates = prepared['outputs']['coordinates'][0]
        compared = run(client, project, 'workbench.compare', {'subject': [coordinates], 'reference': [coordinates]}, {})
        assert compared['status'] == 'succeeded', compared
        assert len(compared['outputs']['comparison']) == 1


@pytest.mark.parametrize('file_format', ['pdb', 'mmcif'])
def test_existing_upstream_tracks_and_file_secondary_records_are_loaded_without_calculation(tmp_path, file_format):
    import gemmi
    from modules.structure_io import parse, encode
    from tests.test_structure_conditions import PDB
    structure = parse(PDB, 'pdb')
    helix = gemmi.Helix()
    helix.pdb_helix_class = gemmi.Helix.HelixClass.RAlpha
    for address in (helix.start, helix.end):
        address.chain_name = 'X'
        address.res_id.seqid = gemmi.SeqId(12, 'A')
        address.res_id.name = 'ALA'
    structure.helices.append(helix)
    content = encode(structure, file_format)
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Existing annotations'}).json()['id']
        obj = {'id': 'source', 'structure': {'file': 'source.cif', 'format': file_format},
               'positions': [{'chain': 'X', 'author_number': 12, 'insertion_code': 'A'}],
               'tracks': {'sasa': [0], 'function_annotations': [{'label': 'binding', 'start': 1, 'end': 1}]}}
        source = upload(client, project, 'workbench.structure_set', {'manifest.json': json.dumps({'objects': [obj]}).encode(), 'source.cif': content})
        result = run(client, project, 'workbench.edit_sequence', {'source': [source['id']]}, {'selection': {'chains': ['X']}})
        assert result['status'] == 'succeeded', result
        actual = client.get(f'/api/packages/{result["outputs"]["edited"][0]}/file', params={'key': 'edited.json'}).json()['tracks']
        assert actual['secondary_structure'] == ['H']
        assert actual['sasa'] == [0]
        assert actual['function_annotations'] == [{'label': 'binding', 'start': 1, 'end': 1}]
