"""Current whole-chain loading: protein tracks and intact source components."""
import json
from pathlib import Path

import gemmi
import pytest
from fastapi.testclient import TestClient

from modules.structure_io.target import write_target
from protein_workbench_public.bootstrap import create_application


def upload(client, project, content, encoding):
    prefix = f'/api/projects/{project}/uploads'
    response = client.post(prefix, json={})
    response.raise_for_status()
    prefix += '/' + response.json()['upload_id']
    files = {'manifest.json': json.dumps({'objects': [{'id': 'input', 'structure': {
        'file': 'original', 'format': encoding}}]}).encode(), 'original': content}
    for key, data in files.items():
        client.put(prefix + '/files', params={'key': key}, content=data).raise_for_status()
    response = client.post(prefix + '/commit', json={
        'format': 'workbench.structure_set', 'entry': 'manifest.json',
        'files': {key: key for key in files}})
    response.raise_for_status()
    return response.json()['id']


def preview(client, project, source, parameters):
    response = client.post(f'/api/projects/{project}/interactions', json={
        'interaction': 'workbench.sequence_edit', 'inputs': {'source': [source]},
        'parameters': parameters})
    response.raise_for_status()
    token = response.json()['id']
    response = client.post(f'/api/interactions/{token}/execute')
    assert response.status_code == 200, response.text
    data = response.json()['data']
    def file(key):
        response = client.get(f'/api/interactions/{token}/file', params={'output': 'edited', 'key': key})
        response.raise_for_status()
        return response
    document = file(data['document_file']).json()
    return token, document, file


def mixed_cif():
    content = write_target([
        {'residue': 'A', 'author_number': 12, 'author_chain': 'X', 'atoms': {'CA': [1, 2, 3]}},
        {'residue': 'G', 'author_number': 13, 'author_chain': 'X', 'atoms': {}},
        {'residue': 'C', 'author_number': 30, 'author_chain': 'X', 'atoms': {'CA': [4, 5, 6]}},
        {'residue': 'X', 'author_number': 31, 'author_chain': 'X', 'atoms': {'CA': [7, 8, 9]}},
        {'residue': 'J', 'author_number': 32, 'author_chain': 'X', 'atoms': {'CA': [10, 11, 12]}},
    ])
    document = gemmi.cif.read_string(content.decode())
    block = document.sole_block()
    block.find_loop('_entity.id').get_loop().add_row(['2', 'water'])
    block.find_loop('_entity.id').get_loop().add_row(['3', 'non-polymer'])
    block.find_loop('_struct_asym.id').get_loop().add_row(['W', '2'])
    block.find_loop('_struct_asym.id').get_loop().add_row(['M', '3'])
    atoms = block.find_loop('_atom_site.id').get_loop()
    for serial, name, element, number, subchain, entity in [
        (5, 'HOH', 'O', 90, 'W', '2'), (6, 'ZN', 'ZN', 91, 'M', '3')]:
        atoms.add_row(['HETATM', str(serial), element, element, '.', name, subchain, entity,
                       '.', '.', '20', '21', '22', '1', '0', str(number), name, 'X', element, '1'])
    values = block.get_mmcif_category('_atom_site.')
    # Interspersed components must not shift the protein's coordinate/label pairing.
    order = [0, 4, 1, 5, 2, 3]
    block.set_mmcif_category('_atom_site.', {key: [column[i] for i in order] for key, column in values.items()})
    return document.as_string().encode()


@pytest.mark.parametrize('encoding', ['pdb', 'mmcif'])
def test_whole_chain_edit_retains_components_and_deletion_survives_reopen(tmp_path, encoding):
    source = Path(__file__).parent / 'fixtures/real_comparisons/round1-candidate1/reference.pdb'
    content = source.read_bytes()
    if encoding == 'mmcif':
        structure = gemmi.read_pdb_string(content)
        structure.setup_entities()
        structure.assign_label_seq_id()
        content = structure.make_mmcif_document().as_string().encode()
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Whole chain'}).json()['id']
        package = upload(client, project, content, encoding)
        token, original, files = preview(client, project, package, {'selection': {'chains': ['A']}})
        assert len(original['positions']) == 56
        assert original['sequence'] == 'MTYKLILNGKTLKGETTTEAVDAATAEKVFKQYANDNGVDGEWTYDDATKTFTVTE'
        assert len([atom for atom in files('view.json').json() if atom['residue_name'] == 'HOH']) == 20
        retained = original['structures'][0]['files']['original']
        assert files(retained).content == content
        removed = original['positions'][9]['id']
        token, edited, files = preview(client, project, {'interaction': token, 'output': 'edited'}, {
            'operation': {'kind': 'delete', 'positions': [removed]}})
        accepted = client.post(f'/api/interactions/{token}/accept', json={'output': 'edited'}).json()
        _, reopened, files = preview(client, project, accepted['id'], {})
        assert len(reopened['positions']) == 55
        assert removed not in [row['id'] for row in reopened['positions']]
        assert reopened['sequence'] == original['sequence'][:9] + original['sequence'][10:]
        assert files(retained).content == content
        assert len([atom for atom in files('view.json').json() if atom['residue_name'] == 'HOH']) == 20


def test_mixed_mmcif_keeps_unobserved_and_extended_protein_positions(tmp_path):
    content = mixed_cif()
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Mixed components'}).json()['id']
        package = upload(client, project, content, 'mmcif')
        _, document, files = preview(client, project, package, {'selection': {'chains': ['X']}})
        assert document['sequence'] == 'AGCXJ'
        assert [row['coordinates'] for row in document['positions']] == [
            {'CA': [1, 2, 3]}, None, {'CA': [4, 5, 6]}, {'CA': [7, 8, 9]}, {'CA': [10, 11, 12]}]
        assert [row['source']['label_position']['position'] for row in document['positions']] == [1, 2, 3, 4, 5]
        assert [row['target_author']['author_number'] for row in document['positions']] == [12, 13, 30, 31, 32]
        assert {'HOH', 'ZN'} <= {atom['residue_name'] for atom in files('view.json').json()}
        assert files(document['structures'][0]['files']['original']).content == content
