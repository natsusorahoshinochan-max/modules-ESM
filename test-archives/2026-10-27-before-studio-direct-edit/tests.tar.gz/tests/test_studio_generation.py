"""The prepared protein crosses generation and returns with independent tracks."""
import io
import json
from types import SimpleNamespace

import pytest

from protein_workbench_public.module_api import Call


class Package:
    def __init__(self, format, document, files=None):
        self.format, self.entry = format, 'manifest.json'
        self._document, self._files = document, files or {}
        self.files = ('manifest.json', *self._files)

    def open(self, key):
        if key == self.entry:
            return io.StringIO(json.dumps(self._document))
        return io.BytesIO(self._files[key])


def test_independent_track_values_reach_esm3_and_native_results_return_to_studio(tmp_path):
    from esm.sdk.api import ESMProtein
    from modules.esm3.adapters import create_remote
    from modules.generation.sequence import execute
    from modules.sequence_edit import _initial
    from modules.sequence_edit.target_delivery import prepared_tracks

    tracks = {
        'sequence': ['A', None, 'D', 'E'],
        'coordinates': [None, None, {'CA': [1., 2., 3.]}, None],
        'secondary_structure': [None, 'H', None, None],
        'sasa': [None, None, None, 12.5],
        'function_annotations': [{'label': 'binding', 'start': 1, 'end': 2}],
    }
    document = {'id': 'protein', 'positions': [{'id': f'p{index}'} for index in range(4)], 'tracks': tracks}
    seen = []

    class Client:
        def generate(self, protein, config):
            import torch
            seen.append(protein)
            assert protein.sequence == 'A_DE'
            assert protein.secondary_structure == '_H__'
            assert protein.sasa == [None, None, None, 12.5]
            assert torch.isnan(protein.coordinates[0]).all()
            assert protein.coordinates[2, 1].tolist() == [1., 2., 3.]
            assert protein.function_annotations[0].end == 2
            assert protein.potential_sequence_of_concern is False
            return ESMProtein(sequence='ACDE', coordinates=protein.coordinates,
                              secondary_structure=protein.secondary_structure,
                              sasa=protein.sasa, function_annotations=protein.function_annotations)

        def close(self):
            pass

    runtime = SimpleNamespace(workdir=tmp_path, cancelled=False, progress=lambda _: None)
    tool = create_remote({}, client_factory=lambda _: Client())
    outcome = execute(Call(inputs={'source': (Package('workbench.protein', document),)},
                           settings={}, parameters={'samples': 1}, tool_parameters={'esm3': {'num_steps': 1}},
                           tools={'esm3': tool}, tool_choices={'esm3': 'test.esm3'}), runtime)
    assert outcome.status == 'succeeded', outcome.diagnostics
    delivery = outcome.outputs['generated'][0]
    manifest = json.loads((tmp_path / delivery.files[delivery.entry]).read_text())
    generated = manifest['objects'][0]
    assert generated['tracks'] == {**tracks, 'sequence': list('ACDE')}
    assert set(generated['generation']) == {'input', 'sample', 'tracks'}
    reopened = _initial(Call(inputs={'source': (Package(delivery.format, manifest),)}, parameters={}, settings={}))
    assert prepared_tracks(reopened) == generated['tracks']
    assert len(seen) == 1


def test_generation_uses_only_prepared_values_when_reference_atoms_exist(tmp_path):
    from modules.generation.sources import read_sources, request_for
    from modules.esm3.adapters import protein_for
    from tests.fixtures.protein import prepared_protein

    document = prepared_protein()
    document['tracks']['coordinates'] = [None, None]
    document['target'] = {'file': 'original.cif', 'format': 'mmcif'}
    package = Package('workbench.protein', document, {'original.cif': b'reference file must not supply cleared atoms'})
    source = read_sources(package)[0]
    native = protein_for(request_for('sequence', source['tracks']))
    import torch
    assert torch.isnan(native.coordinates).all()


def test_generation_rejects_second_scientific_edit_state_in_node_parameters(tmp_path):
    from modules.generation.sequence import execute
    with pytest.raises(ValueError, match='tracks come from'):
        execute(Call(inputs={}, parameters={'conditions': {'sasa': [1.]}}, settings={}), SimpleNamespace(workdir=tmp_path))
