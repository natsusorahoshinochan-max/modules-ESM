"""User-facing five-track editing and portable canvas handoff."""
import json

import pytest
from fastapi.testclient import TestClient

from modules.structure_io.target import read_target
from protein_workbench_public.bootstrap import create_application
from tests.test_editor_interactions import preview
from tests.test_sequence_io import upload
from tests.test_structure_io import run


def manifest(client, token):
    response = client.get(f'/api/interactions/{token}/file', params={'output': 'edited', 'key': 'edited.json'})
    response.raise_for_status()
    return response.json()


def test_independent_tracks_survive_insert_delete_reorder_and_clear(tmp_path):
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Five independent tracks'}).json()['id']
        token, first = preview(client, project, {'sequence': 'ACDE'})
        ids = [row['id'] for row in first['positions']]
        token, edited = preview(client, project, {'operations': [
            {'kind': 'update', 'positions': [ids[0]], 'changes': {'residue': None}},
            {'kind': 'update', 'positions': [ids[1]], 'changes': {'coordinates': {'CA': [1, 2, 3]}}},
            {'kind': 'update', 'positions': [ids[2]], 'changes': {'secondary_structure': 'E'}},
            {'kind': 'update', 'positions': [ids[3]], 'changes': {'sasa': 17.5}},
            {'kind': 'update', 'positions': [ids[1], ids[2]], 'changes': {'function_annotations': ['binding']}},
            {'kind': 'insert', 'index': 2, 'sequence': '_'},
        ]}, {'source': [{'interaction': token, 'output': 'edited'}]})
        assert client.get(f'/api/projects/{project}/packages').json() == []
        assert manifest(client, token)['tracks'] == {
            'sequence': [None, 'C', None, 'D', 'E'],
            'coordinates': [None, {'CA': [1, 2, 3]}, None, None, None],
            'secondary_structure': [None, None, None, 'E', None],
            'sasa': [None, None, None, None, 17.5],
            'function_annotations': [{'label': 'binding', 'start': 2, 'end': 2}, {'label': 'binding', 'start': 4, 'end': 4}],
        }
        blank = edited['positions'][2]['id']
        token, changed = preview(client, project, {'operations': [
            {'kind': 'delete', 'positions': [ids[1]]},
            {'kind': 'reorder', 'positions': [ids[3], ids[2], blank, ids[0]]},
            {'kind': 'update', 'positions': [ids[2]], 'changes': {'residue': 'G'}},
        ]}, {'source': [{'interaction': token, 'output': 'edited'}]})
        tracks = manifest(client, token)['tracks']
        assert tracks['function_annotations'] == [{'label': 'binding', 'start': 2, 'end': 2}]
        assert tracks['sasa'] == [17.5, None, None, None]
        assert tracks['secondary_structure'] == [None, 'E', None, None]
        assert tracks['sequence'] == ['E', 'G', None, None]
        assert [row['id'] for row in changed['positions']] == [ids[3], ids[2], blank, ids[0]]


def test_complete_sequence_output_is_separate_and_masked_output_stays_available(tmp_path):
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Prepared outputs'}).json()['id']
        complete = run(client, project, 'workbench.edit_sequence', {}, {'sequence': 'ACD'})
        assert complete['status'] == 'succeeded', complete
        assert set(complete['outputs']) == {'edited', 'sequence', 'coordinates', 'secondary_structure', 'sasa', 'function_annotations'}
        seq_package = complete['outputs']['sequence'][0]
        sequence = client.get(f'/api/packages/{seq_package}/file', params={'key': 'sequence.json'}).json()
        assert sequence['objects'][0]['sequence'] == 'ACD'
        masked = run(client, project, 'workbench.edit_sequence', {}, {'sequence': 'A_D'})
        assert masked['status'] == 'succeeded', masked
        assert client.get(f"/api/packages/{masked['outputs']['sequence'][0]}/file", params={'key': 'sequence.json'}).json()['objects'][0]['sequence'] == 'A_D'
        package = masked['outputs']['edited'][0]
        protein = client.get(f'/api/packages/{package}/file', params={'key': 'edited.json'}).json()
        assert protein['tracks']['sequence'] == ['A', None, 'D']
        assert all(not {'fixed', 'prompt', 'residue'} & set(row) for row in protein['positions'])


@pytest.mark.parametrize('source_format', ['workbench.esm3_generation', 'workbench.joint_generation'])
def test_generated_partial_tracks_return_to_studio_and_retain_source_files(tmp_path, source_format):
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Generated five-track input'}).json()['id']
        tracks = {'sequence': ['A', None, 'G'], 'coordinates': [{'CA': [1, 2, 3]}, None, {'N': [6, 7, 8]}],
                  'secondary_structure': [None, 'H', 'C'], 'sasa': [8, None, 17.5],
                  'function_annotations': [{'label': 'IPR000001', 'start': 2, 'end': 3}]}
        source = upload(client, project, source_format, {
            'manifest.json': json.dumps({'objects': [{'id': 'generated', 'tracks': tracks, 'native': {'file': 'native.json'}}]}).encode(),
            'native.json': b'{"original":true}', 'research.txt': b'keep source research',
        })
        token, document = preview(client, project, {}, {'source': [source['id']]})
        assert manifest(client, token)['tracks'] == tracks
        assert document['positions'][1]['residue'] is None
        assert document['positions'][1]['coordinates'] is None
        accepted = client.post(f'/api/interactions/{token}/accept', json={'output': 'edited'}).json()
        target = read_target(client.get(f'/api/packages/{accepted["id"]}/file', params={'key': 'target.cif'}).content)
        assert target['sequence'] == 'AXG'
        assert [row['atoms'] for row in target['positions']] == [{'CA': [1, 2, 3]}, {}, {'N': [6, 7, 8]}]
        retained = document['sources'][0]['files']['research.txt']
        assert client.get(f'/api/packages/{accepted["id"]}/file', params={'key': retained}).content == b'keep source research'
        next_token, _ = preview(client, project, {'operations': [
            {'kind': 'transform_coordinates', 'indices': [1], 'rotation': [[1, 0, 0], [0, 1, 0], [0, 0, 1]], 'translation': [2, 0, 0]},
            {'kind': 'update', 'indices': [3], 'changes': {'coordinates': None}},
        ]}, {'source': [accepted['id']]})
        current = manifest(client, next_token)
        assert current['tracks']['coordinates'] == [{'CA': [3, 2, 3]}, None, None]
        assert current['tracks']['secondary_structure'] == tracks['secondary_structure']
        file = client.get(f'/api/interactions/{next_token}/file', params={'output': 'edited', 'key': 'target.cif'})
        assert read_target(file.content)['positions'][2]['atoms'] == {}


def test_missing_generated_tracks_stay_blank_and_no_editor_history_is_required(tmp_path):
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Portable values'}).json()['id']
        source = upload(client, project, 'workbench.esm3_generation', {
            'manifest.json': json.dumps({'objects': [{'id': 'generated', 'tracks': {'sequence': ['A', 'C']}}]}).encode()})
        token, _ = preview(client, project, {}, {'source': [source['id']]})
        values = manifest(client, token)
        assert values['tracks']['coordinates'] == [None, None]
        assert values['tracks']['secondary_structure'] == [None, None]
        assert values['tracks']['sasa'] == [None, None]
        assert values['tracks']['function_annotations'] == []
        # A third-party producer needs only the prepared public data, not editor.json.
        values.pop('sources')
        values.pop('target')
        third_party = upload(client, project, 'workbench.protein', {'protein.json': json.dumps(values).encode()}, entry='protein.json')
        _, reopened = preview(client, project, {}, {'source': [third_party['id']]})
        assert reopened['sequence'] == 'AC'
        assert reopened['random_operations'] == []


def test_generated_sequence_roundtrip_retains_real_author_and_label_correspondence(tmp_path):
    with TestClient(create_application(data_root=tmp_path)) as client:
        project = client.post('/api/projects', json={'name': 'Generated correspondence'}).json()['id']
        origin = {'object': 'original', 'position': {'chain': 'Q', 'author_number': 92, 'insertion_code': 'B'},
                  'label_position': {'chain': 'A', 'position': 1}}
        source = upload(client, project, 'workbench.esm3_generation', {
            'manifest.json': json.dumps({'objects': [{'id': 'generated', 'tracks': {'sequence': ['A']},
                'positions': [{'sequence_index': 1, 'source': origin}]}]}).encode()})
        token, document = preview(client, project, {}, {'source': [source['id']]})
        assert document['positions'][0]['source'] == origin
        response = client.get(f'/api/interactions/{token}/file', params={'output': 'sequence', 'key': 'sequence.json'})
        response.raise_for_status()
        assert response.json()['objects'][0]['positions'] == [{'sequence_index': 1, 'id': document['positions'][0]['id'], 'chain': 'Q',
            'author_number': 92, 'insertion_code': 'B', 'label_position': {'chain': 'A', 'position': 1}}]
